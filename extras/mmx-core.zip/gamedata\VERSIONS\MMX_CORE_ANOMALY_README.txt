MMX - Core [Anomaly]
====================

Pacchetto Essenziale MMX-Net / Logan: fix e cambiamenti Anomaly nostri.
Non Ã¨ branding Razom. Non sostituisce Base Coop (engine) nÃ© l'overlay MMX_NET (AGGIORNA).

Installazione
-------------
- Automatica: installer + first-run launcher + card Addons â†’ Essenziali.
- Zip: extras/mmx-core.zip (oppure feed MMX-Net).
- Organizer: riga Â«MMX - Core [Anomaly]Â» (enable/disable via park _mmx_parked/mmx-core/).

Contenuto attuale (v0.1.16)
--------------------------
Diversificazione famiglie AK — 0.1.16:
  - mod_system_zzzz_mmx_core_ak_family_balance.ltx (35 sezioni: CGP + MRAA ref + BaS)
  - Ruoli: 74U CQB / 5.45 lunga+carb / 7.62+104 / 5.56 101+102 / AK-12 / RPK-74
  - handling per ruolo; fix realism: AK-103 ammo_mag 30, AKSU ISG/tac bullet_speed
  - Generator: _gen_mmx_core_ak_family_balance.py
  - Sostituisce recoil_balance globale (54 armi) — solo AK, trade-off coop-safe
  - cfg parity host+peer (HELLO weapon params)

Contenuto precedente (v0.1.15)
--------------------------
AK family balance MVP (23 sezioni LTX-only).

Contenuto precedente (v0.1.14)
--------------------------
Priority faction tactics MVP — 0.1.14:
  - Monolith / Merc / Duty / Army / Freedom: MMX_CORE_priority_faction_tactics.script (host-only)
    comms/barks, call squad, combat bias (press / fireteam / hold / range / flank)
  - F2 LTX: mod_system_zzzz_mmx_faction_ai_f2_fire_queue.ltx + f2_rank.ltx (fire_queue + Army eye / Duty hold)
  - cfg parity host+peer; warfare preset MCM = Fase 4 (non in questo pack)

Contenuto precedente (v0.1.13)
--------------------------
Bandit tactics MVP — 0.1.13:
  - hit bandit = loner baseline (0%); eye 142 / ignore 68 / panic 0.02 invariati
  - MMX_CORE_bandit_tactics.script (host-only: barks, call friends, loot greed best-effort)
  - loader MMX_CORE_faction_ai.script

Contenuto precedente (v0.1.12)
--------------------------
Faction AI P0 — 0.1.12:
  - mod_system_zzzz_mmx_faction_ai.ltx (DLTX sim_default_* per fazione/rank)
  - script MMX_CORE_faction_ai.script (marker; MCM/warfare = fasi future)
  - cfg fingerprint HELLO — stesso Core su host e peer

Contenuto precedente (v0.1.11)
--------------------------
Migrato da Essentials Survival (extras/essentials.zip):
  - marker di detect (ora MMX_CORE_ANOMALY.ltx)
  - note safe-defaults coop (testo)

PDA QoS + EA/FDDA version gate — NEW 0.1.11:
  - script MMX_CORE_pda_qos.script
      * UnregisterScriptCallback su check_for_game_ver (fix vs soft-replace 0.1.10)
      * init ea_dummy_var + ea_error_ONOk safe; poll finché EA carica
  - patch sorgente enhanced_animations.script (no popup 1.5.3, no CTD crash-me)
      * soft-unlock theme PDA mission se bloccati (no rumble; rumble = Optional MMX-PDA)
      * nessun LTX → no cfg fingerprint HELLO

Seconda bussola (Tactical Compass) — NEW 0.1.8:
  - script MMX_CORE_second_compass.script
      * soft-gate marker MMX_OPT_TACTICAL_COMPASS (o script tc_*)
      * se TC assente: no-op + tip opzionale
      * se TC presente: seconda strip HUD (bordo opposto), stile/scale da tc_mcm
      * NON tocca tc_hud.HUD / marker entry.ui / set_scale (coesistenza)
  - MCM: zzzz_mmx_core_mcm.script → MMX-Net → Core
      * toggle «Seconda bussola (Tactical)» default ON
  - text eng/ita: ui_mmx_core_second_compass.xml
  - Nessun box_*.ltx / no HELLO fingerprint extra

QAW Y-only (Quick Action Wheel) — NEW 0.1.7:
  - script zzzz_mmx_core_qaw_y_only.script
      * mini-menu Haru/QAW Overhaul apre SOLO con Y
      * F resta Use/Talk (niente rubare interact NPC)
      * disattiva override quick-use 1–4 e ammo wheel come open-path
      * numeri 1–N switchano tab solo a menu già aperto
  - Nessun LTX / no HELLO fingerprint extra

Companion revive soft-gate — NEW 0.1.6:
  - script MMX_CORE_companion_revive.script
      * detect marker MMX_OPT_ANIMATED_NPC_HEALING (o script autore)
      * API can_rescue() / tip_blocked() usata da MMX_NET_wounded
      * senza ANH: RescueKeyDown annullato + tip EN/IT
      * con ANH: revive peer + medikit (C++) + anim pack ANH
  - text eng/ita: ui_mmx_core_revive.xml
  - Nessun box_*.ltx / no HELLO fingerprint extra

Movement feel (ARK-soft / STALKER) — NEW 0.1.4 (estende run-speed 0.1.3):
  - script MMX_CORE_run_speed.script
      * mul arma: bare 1.00 / pistol 1.04 / knife 1.06 / rifle 1.00 / heavy 0.98
      * backward (walk+runback): mul 0.80 — non si corre veloce all'indietro
      * strafe in ADS/mira: mul 0.85 vs strafe hipfire
      * API: speed.add_speed (run+sprint) + set_actor_runback/walk_back/strafe_coef
      * Toggle ENABLED + INTENSITY hardcoded (nessun MCM Core ancora)
      * Prima 0.1.2: nessun mul → mani nude = turbo relativo
  - Nessun LTX weapon / nessun MCM / no cfg fingerprint extra


Fonts join-safe — NEW 0.1.5:
  - configs/fonts.ltx = VANILLA (stesso SHA overlay pack) — niente cfg-diff fonts
  - VERSIONS/MMX_CORE_FONTS_AVANT_GARDE_ALIASES.txt = sezioni ui_font_mmx_avant_garde_*
    (documentate; append solo con rollout coordinato su tutti i PC)
  - textures Avant Garde dedicate ui_font_mmx_avant_garde_* (+ Elegant gia' in 0.1.2)
  - Nessuna API exclude fingerprint EXE: join OK = stesso fonts.ltx su host e peer
  - HEALTH launcher: cfg-diff solo fonts.ltx non alza chip DESYNC critico
Font UI MMX Elegant â€” NEW 0.1.2:
  - textures/ui/ui_font_graff_{19,22,32}_{800,1024,1600}*.{dds,ini,thm}
    (+ _west / _cent) â€” override atlas graffiti menu/ambient
  - copie dedicate ui_font_mmx_elegant_{19,22,32}_{res}.*
  - README_MMX_UI_FONTS.txt in textures/ui/
  - Optional cosmetic via extras/mmx-core.zip (Ensure/AGGIORNA Core).
    NON in ac_pack_include / OverlayIntegrity â€” display only, no desync/join.
  - TTF Elegant NON incluso (licenza personal use â€” Assets/Fonts/).

Hitch / frame-drop (vetri, spari, casse) â€” 0.1.1:
  - script MMX_CORE_hitch_particles.script
      * r2_soft_particles off (spike vetri / debris / puff armi)
      * particle_update_mod <= 0.25 (solo abbassa)
      * mt_particles / mt_bullets on (se cvar Modded Exes presenti)
      * render_short_tracers on
      * apply a actor_on_first_update, senza cfg_save
  - override casse: configs/models/objects/box_wood_01, box_lab_02,
    box_paper, box_metall_01 â€” destroy_particles vuoto (meno FX alla rottura)
  - JOIN-CRITICAL: i box_*.ltx entrano nel cfg fingerprint HELLO.
    Host e peer devono avere lo stesso Core (o entrambi senza).
    Font atlas Elegant = solo cosmetic (non kick). PDA / Zaino Gate = no cfg LTX.

Causa hitch tipica Anomaly/GAMMA: soft particles + destroy_fx/hit_glass densi
al break o al fuoco. Non shippiamo particles.xr GAMMA massivi.

Core coop anti-CTD sessione resta nell'overlay AGGIORNA (non in questo zip):
  - alife_release ownership, inventory send-money, message_box bridge, currency,
    radio soft-match, death_manager / ChangeLevel guard, residuali meet/rf/hfâ€¦

Migrazione Survival â†’ Core
--------------------------
Se era installato Essentials Survival (MMX_ESSENTIALS.ltx / park essentials),
il launcher rimuove i marker Survival e installa Core. Nessun impatto save
previsto (solo file VERSIONS overlay + contenuti Core).

Fase 2 â€” TODO (non implementare ora)
------------------------------------
1) DifficoltÃ  nemici / danni
2) IA Monolith piÃ¹ aggressiva / intelligente
Vedi MMX-net/docs/MMX_CORE_ANOMALY.md

Safe defaults (consigli â€” non applicati automaticamente)
--------------------------------------------------------
  - MCM completo + Engine Base Coop dalle card dedicate.
  - Dopo AGGIORNA, fingerprint overlay allineato prima del Join.
  - Non mischiare overlay parziali sopra Core senza need.

Smoke mentale hitch
-------------------
In mondo: sparare verso vetri, rompere casse legno/carta/metallo â€” niente spike
lunghi. Soft particles restano off finchÃ© Core Ã¨ installato (ri-apply ogni load).

Documentazione: MMX-net/docs/MMX_CORE_ANOMALY.md
