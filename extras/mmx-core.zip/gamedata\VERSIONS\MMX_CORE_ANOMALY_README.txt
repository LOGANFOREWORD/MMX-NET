MMX - Core [Anomaly]
====================

Pacchetto Essenziale MMX-Net / Logan: fix e cambiamenti Anomaly nostri.
Non Ã¨ branding Razom. Non sostituisce Base Coop (engine) nÃ© l'overlay MMX_NET (AGGIORNA).

Installazione
-------------
- Automatica: installer + first-run launcher + card Addons â†’ Essenziali.
- Zip: extras/mmx-core.zip (oppure feed MMX-Net).
- Organizer: riga Â«MMX - Core [Anomaly]Â» (enable/disable via park _mmx_parked/mmx-core/).

Contenuto attuale (v0.1.4)
--------------------------
Migrato da Essentials Survival (extras/essentials.zip):
  - marker di detect (ora MMX_CORE_ANOMALY.ltx)
  - note safe-defaults coop (testo)

Movement feel (ARK-soft / STALKER) — NEW 0.1.4 (estende run-speed 0.1.3):
  - script MMX_CORE_run_speed.script
      * mul arma: bare 1.00 / pistol 1.04 / knife 1.06 / rifle 1.00 / heavy 0.98
      * backward (walk+runback): mul 0.80 — non si corre veloce all'indietro
      * strafe in ADS/mira: mul 0.85 vs strafe hipfire
      * API: speed.add_speed (run+sprint) + set_actor_runback/walk_back/strafe_coef
      * Toggle ENABLED + INTENSITY hardcoded (nessun MCM Core ancora)
      * Prima 0.1.2: nessun mul → mani nude = turbo relativo
  - Nessun LTX weapon / nessun MCM / no cfg fingerprint extra

Font UI MMX Elegant â€” NEW 0.1.2:
  - textures/ui/ui_font_graff_{19,22,32}_{800,1024,1600}*.{dds,ini,thm}
    (+ _west / _cent) â€” override atlas graffiti menu/ambient
  - copie dedicate ui_font_mmx_elegant_{19,22,32}_{res}.*
  - README_MMX_UI_FONTS.txt in textures/ui/
  - Optional cosmetic via extras/mmx-core.zip (Ensure/AGGIORNA Core).
    NON in ac_pack_include / OverlayIntegrity â€” display only, no desync/join.
  - TTF Elegant NON incluso (licenza personal use â€” Assets/Fonts/).

Hitch / frame-drop (vetri, spari, casse) â€” 0.1.1:
  - script MMX_CORE_hitch_particles.script
      * r2_soft_particles off (spike vetri / debris / puff armi)
      * particle_update_mod <= 0.25 (solo abbassa)
      * mt_particles / mt_bullets on (se cvar Modded Exes presenti)
      * render_short_tracers on
      * apply a actor_on_first_update, senza cfg_save
  - override casse: configs/models/objects/box_wood_01, box_lab_02,
    box_paper, box_metall_01 â€” destroy_particles vuoto (meno FX alla rottura)
  - JOIN-CRITICAL: i box_*.ltx entrano nel cfg fingerprint HELLO.
    Host e peer devono avere lo stesso Core (o entrambi senza).
    Font atlas Elegant = solo cosmetic (non kick). PDA / Zaino Gate = no cfg LTX.

Causa hitch tipica Anomaly/GAMMA: soft particles + destroy_fx/hit_glass densi
al break o al fuoco. Non shippiamo particles.xr GAMMA massivi.

Core coop anti-CTD sessione resta nell'overlay AGGIORNA (non in questo zip):
  - alife_release ownership, inventory send-money, message_box bridge, currency,
    radio soft-match, death_manager / ChangeLevel guard, residuali meet/rf/hfâ€¦

Migrazione Survival â†’ Core
--------------------------
Se era installato Essentials Survival (MMX_ESSENTIALS.ltx / park essentials),
il launcher rimuove i marker Survival e installa Core. Nessun impatto save
previsto (solo file VERSIONS overlay + contenuti Core).

Fase 2 â€” TODO (non implementare ora)
------------------------------------
1) DifficoltÃ  nemici / danni
2) IA Monolith piÃ¹ aggressiva / intelligente
Vedi MMX-net/docs/MMX_CORE_ANOMALY.md

Safe defaults (consigli â€” non applicati automaticamente)
--------------------------------------------------------
  - MCM completo + Engine Base Coop dalle card dedicate.
  - Dopo AGGIORNA, fingerprint overlay allineato prima del Join.
  - Non mischiare overlay parziali sopra Core senza need.

Smoke mentale hitch
-------------------
In mondo: sparare verso vetri, rompere casse legno/carta/metallo â€” niente spike
lunghi. Soft particles restano off finchÃ© Core Ã¨ installato (ri-apply ogni load).

Documentazione: MMX-net/docs/MMX_CORE_ANOMALY.md
