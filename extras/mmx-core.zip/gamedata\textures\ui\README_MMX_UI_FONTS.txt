﻿MMX UI fonts (Elegant override)
================================
Atlas graffiti19/22/32 overridden with Elegant (fitted metriche vanilla).
Live path: gamedata/textures/ui/ui_font_graff_* (+ copie ui_font_mmx_elegant_*).
Pack: extras/mmx-core.zip (MMX - Core [Anomaly]) — optional cosmetic.
NON in ac_pack_include / NON in OverlayIntegrity: font ≠ stato rete;
Elegant vs vanilla NON causa desync/join kick. Solo testo display locale.
Nessun download «font del peer» in sessione. TTF sorgente NON incluso
(licenza personal use — Assets/Fonts/).
Vedi Assets/Fonts/README_MMX_ELEGANT.md e MMX-net/docs/MMX_CORE_ANOMALY.md.
