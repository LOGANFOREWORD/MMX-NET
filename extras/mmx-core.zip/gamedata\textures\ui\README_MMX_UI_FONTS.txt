﻿MMX UI fonts — stato

graffiti19/22/32 = atlas GRAFFITI VANILLA (ripristinati 2026-10-02).

Elegant Personal Use (hairline) non è adatto al menu HUD a 19/22px:
troppo thin / AA scarso su fondo scuro. Priorità leggibilità > brand.

Builder sperimentale: Assets/Fonts/build_mmx_elegant_anomaly_fonts.py
  --restore-vanilla   (default operativo attuale)
  --stroke N --boost F  (solo test locali)

Elegant vs vanilla NON causa desync/join. Solo testo display locale.
TTF Elegant NON incluso (licenza personal use).
