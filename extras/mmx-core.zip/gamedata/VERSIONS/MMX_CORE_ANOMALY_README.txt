MMX - Core [Anomaly]
====================

Pacchetto Essenziale MMX-Net / Logan: fix e cambiamenti Anomaly nostri.
Non è branding Razom. Non sostituisce Base Coop (engine) né l'overlay MMX_NET (AGGIORNA).

Installazione
-------------
- Automatica: installer + first-run launcher + card Addons → Essenziali.
- Zip: extras/mmx-core.zip (oppure feed MMX-Net).
- Organizer: riga «MMX - Core [Anomaly]» (enable/disable via park _mmx_parked/mmx-core/).

Contenuto attuale (v0.1.0)
--------------------------
Migrato da Essentials Survival (extras/essentials.zip):
  - marker di detect (ora MMX_CORE_ANOMALY.ltx)
  - note safe-defaults coop (testo)
  - scaffold per futuri fix Anomaly QoL / balance

Core coop anti-CTD sessione resta nell'overlay AGGIORNA (non in questo zip):
  - alife_release ownership, inventory send-money, message_box bridge, currency,
    radio soft-match, death_manager / ChangeLevel guard, residuali meet/rf/hf…

Migrazione Survival → Core
--------------------------
Se era installato Essentials Survival (MMX_ESSENTIALS.ltx / park essentials),
il launcher rimuove i marker Survival e installa Core. Nessun impatto save
previsto (solo file VERSIONS overlay).

Fase 2 — TODO (non implementare ora)
------------------------------------
1) Difficoltà nemici / danni
   - Candidate LTX: gamedata/configs/creatures/*.ltx, damage.ltx / damages.ltx,
     weapon_* damage sections, game_difficulties / actor damage multipliers.
   - Candidate script: gamedata/scripts/*damage*, *difficulty*, *actor* hit hooks.
   - Doc: MMX-net/docs/MMX_CORE_ANOMALY.md § Fase 2 Balance

2) IA Monolith più aggressiva / intelligente
   - Candidate LTX: gamedata/configs/scripts/monolith*, stalkers_monolith*,
     combat_* / stalker relations, smart_terrain / squad configs.
   - Candidate script: gamedata/scripts/*monolith*, *combat*, *enemy*, binder AI.
   - Doc: MMX-net/docs/MMX_CORE_ANOMALY.md § Fase 2 IA Monolith

Safe defaults (consigli — non applicati automaticamente)
--------------------------------------------------------
  - MCM completo + Engine Base Coop dalle card dedicate.
  - Dopo AGGIORNA, fingerprint overlay allineato prima del Join.
  - Non mischiare overlay parziali sopra Core senza need.

Documentazione: MMX-net/docs/MMX_CORE_ANOMALY.md
