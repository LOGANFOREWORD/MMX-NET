MMX - Core [Anomaly]
====================

Pacchetto Essenziale MMX-Net / Logan: fix e cambiamenti Anomaly nostri.
Non è branding Razom. Non sostituisce Base Coop (engine) né l'overlay MMX_NET (AGGIORNA).

Installazione
-------------
- Automatica: installer + first-run launcher + card Addons → Essenziali.
- Zip: extras/mmx-core.zip (oppure feed MMX-Net).
- Organizer: riga «MMX - Core [Anomaly]» (enable/disable via park _mmx_parked/mmx-core/).

Contenuto attuale (v0.1.1)
--------------------------
Migrato da Essentials Survival (extras/essentials.zip):
  - marker di detect (ora MMX_CORE_ANOMALY.ltx)
  - note safe-defaults coop (testo)

Hitch / frame-drop (vetri, spari, casse) — NEW 0.1.1:
  - script MMX_CORE_hitch_particles.script
      * r2_soft_particles off (spike vetri / debris / puff armi)
      * particle_update_mod <= 0.25 (solo abbassa)
      * mt_particles / mt_bullets on (se cvar Modded Exes presenti)
      * render_short_tracers on
      * apply a actor_on_first_update, senza cfg_save
  - override casse: configs/models/objects/box_wood_01, box_lab_02,
    box_paper, box_metall_01 — destroy_particles vuoto (meno FX alla rottura)

Causa hitch tipica Anomaly/GAMMA: soft particles + destroy_fx/hit_glass densi
al break o al fuoco. Non shippiamo particles.xr GAMMA massivi.

Core coop anti-CTD sessione resta nell'overlay AGGIORNA (non in questo zip):
  - alife_release ownership, inventory send-money, message_box bridge, currency,
    radio soft-match, death_manager / ChangeLevel guard, residuali meet/rf/hf…

Migrazione Survival → Core
--------------------------
Se era installato Essentials Survival (MMX_ESSENTIALS.ltx / park essentials),
il launcher rimuove i marker Survival e installa Core. Nessun impatto save
previsto (solo file VERSIONS overlay + contenuti Core).

Fase 2 — TODO (non implementare ora)
------------------------------------
1) Difficoltà nemici / danni
2) IA Monolith più aggressiva / intelligente
Vedi MMX-net/docs/MMX_CORE_ANOMALY.md

Safe defaults (consigli — non applicati automaticamente)
--------------------------------------------------------
  - MCM completo + Engine Base Coop dalle card dedicate.
  - Dopo AGGIORNA, fingerprint overlay allineato prima del Join.
  - Non mischiare overlay parziali sopra Core senza need.

Smoke mentale hitch
-------------------
In mondo: sparare verso vetri, rompere casse legno/carta/metallo — niente spike
lunghi. Soft particles restano off finché Core è installato (ri-apply ogni load).

Documentazione: MMX-net/docs/MMX_CORE_ANOMALY.md
