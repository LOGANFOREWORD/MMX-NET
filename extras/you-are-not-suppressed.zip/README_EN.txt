YOU ARE (NOT) SUPPRESSED
R1nk1_Suppressed v1.0 FINAL
by R1nk1
========================================

PURPOSE
-------
Adds Squad-like player suppression to S.T.A.L.K.E.R. Anomaly.

The mod does not approximate suppression from damage or from generic gunfire.
It tracks real bullets passing near the player.

HOW IT WORKS
------------
- A real bullet near-miss adds suppression.
- Closer bullet passes add more suppression.
- Dense automatic fire naturally stacks from multiple projectiles.
- Suppression depends on weapon class and receives an additional caliber multiplier.
- Pistols and SMGs are weaker.
- Assault rifles are medium.
- DMRs, sniper rifles, machine guns and heavy weapons are much stronger.
- If an NPC fires while the SHOOTER is within 7 m of the player, a separate
  light vignette pulse is added. This uses shooter distance, not bullet distance.
- Shotgun pellets from one muzzle blast are debounced so one shot does not
  count as many separate close-gunshot pulses.

VFX
---
The final build deliberately uses a small and stable visual stack:
- one DDS vignette;
- stock snd_shock.ppe;
- smooth attack and recovery;
- no 3/12/32-frame texture stacks;
- no custom PPE files that caused native crashes during testing.

REQUIREMENTS
------------
Required:
- S.T.A.L.K.E.R. Anomaly 1.5.3
- Modded Exes with bullet callbacks / DXML

Optional:
- MCM. The mod works with built-in defaults when MCM is absent.

INSTALLATION
------------
Extract the archive into the Anomaly root folder or install it through Mod Organizer.

Core filenames intentionally remain compatible with the test builds, so installing
v1.0 over a previous version overwrites the active scripts instead of loading two
suppression systems at once.

MCM
---
Menu: You are (not) suppressed

Gameplay:
- Enable suppression
- Master suppression strength
- Near-miss radius scale
- Suppression hold time
- Suppression decay rate

Visual Effects:
- Post-process strength
- Post-process threshold
- Vignette strength
- Close-gunshot vignette radius
- Vignette at outer radius
- Vignette at point-blank
- Close-gunshot vignette decay
- Visual attack speed
- Visual recovery speed

Weapon Profiles:
- Pistol
- SMG
- Assault rifle
- Shotgun
- DMR
- Sniper
- Machine gun
- Heavy weapon

Every setting includes an EN/RU tooltip.

THRESHOLD
---------
Post-process threshold is the suppression level where snd_shock.ppe starts to appear.

Example:
0.08 = post-process begins after 8% suppression.
Lower value = the effect begins earlier.

DECAY
-----
For suppression decay and close-gunshot vignette decay:
lower value = the effect lasts longer.

RELEASE DEFAULTS
----------------
Master strength: 1.50
Near-miss radius: 1.15
Hold: 700 ms
Suppression decay: 0.27

PPE strength: 0.135
PPE threshold: 0.08
Vignette: 120
Visual attack: 3.80
Visual release: 0.65

Pistol: 0.80
SMG: 1.20
Rifle: 1.45
Shotgun: 1.65
DMR: 2.40
Sniper: 3.00
Machine gun: 3.00
Heavy: 3.50

COMPATIBILITY / ARCHITECTURE
----------------------------
The mod does not directly replace base XML files.
One HUD static is inserted through DXML.
MCM is optional.

The internal MCM ID stays "r1sup" so existing test-version settings are preserved.

UPGRADING FROM OLD TEST BUILDS
------------------------------
These experimental files are no longer used and may be removed:

gamedata/anims/r1nk1_suppression_bw.ppe

Old DDS files:
r1nk1_suppression_weak.dds
r1nk1_suppression_medium.dds
r1nk1_suppression_strong.dds
r1nk1_suppression_01.dds ... r1nk1_suppression_32.dds

DO NOT remove:
r1nk1_suppression_vignette.dds

SUCCESS LOG
-----------
[R1nk1 Suppressed] v1.0 FINAL loaded
