YOU ARE (NOT) SUPPRESSED
R1nk1_Suppressed v1.0 FINAL
by R1nk1
========================================

ЦЕЛЬ
----
Добавить в S.T.A.L.K.E.R. Anomaly подавление огнём в духе Squad.

Мод реагирует не на урон и не на сам факт стрельбы где-то на локации,
а на реальные пули, проходящие рядом с игроком.

КАК ЭТО РАБОТАЕТ
----------------
- Реальный near-miss пули повышает suppression.
- Чем ближе пуля проходит к камере игрока, тем сильнее вклад.
- Плотный огонь естественно накапливает suppression от нескольких пуль.
- Сила зависит от класса оружия и дополнительно от калибра.
- Пистолеты и ПП слабее.
- Автоматы средние.
- DMR, снайперки, пулемёты и тяжёлое оружие значительно сильнее.
- Если NPC стреляет, находясь в пределах 7 м от игрока, добавляется
  отдельный лёгкий импульс виньетки. Это зависит от расстояния до СТРЕЛКА,
  а не от расстояния до пули.
- Для дробовиков несколько дробин одного выстрела не считаются
  несколькими отдельными близкими выстрелами.

VFX
---
Финальная версия сознательно использует простую и стабильную схему:
- одна DDS-виньетка;
- штатный snd_shock.ppe;
- плавное нарастание и восстановление;
- никаких пачек из 3/12/32 кадров;
- никаких кастомных PPE, которые вызывали нативные вылеты на тестах.

ТРЕБОВАНИЯ
----------
Обязательно:
- S.T.A.L.K.E.R. Anomaly 1.5.3
- Modded Exes с bullet callbacks / DXML

Опционально:
- MCM. Без MCM мод продолжает работать на встроенных значениях.

УСТАНОВКА
---------
Распаковать содержимое архива в корень Anomaly или установить через Mod Organizer.

Если ставится поверх тестовой версии, основные файлы будут перезаписаны,
потому что внутренние имена файлов специально сохранены совместимыми.

MCM
---
Меню: You are (not) suppressed

Gameplay:
- Enable suppression
- Master suppression strength
- Near-miss radius scale
- Suppression hold time
- Suppression decay rate

Visual Effects:
- Post-process strength
- Post-process threshold
- Vignette strength
- Close-gunshot vignette radius
- Vignette at outer radius
- Vignette at point-blank
- Close-gunshot vignette decay
- Visual attack speed
- Visual recovery speed

Weapon Profiles:
- Pistol
- SMG
- Assault rifle
- Shotgun
- DMR
- Sniper
- Machine gun
- Heavy weapon

У каждого параметра есть RU/EN tooltip с объяснением.

ВАЖНО ПРО "ПОРОГ"
-----------------
Post-process threshold = уровень suppression, после которого начинает
проявляться snd_shock.ppe.

Пример:
0.08 = post-process начинает появляться после 8% suppression.
Чем меньше число, тем раньше появляется эффект.

ВАЖНО ПРО "DECAY"
-----------------
Suppression decay rate и Close-gunshot vignette decay работают так:
чем МЕНЬШЕ значение, тем ДОЛЬШЕ держится эффект.

РЕЛИЗНЫЙ БАЛАНС
---------------
Master strength: 1.50
Near-miss radius: 1.15
Hold: 700 ms
Suppression decay: 0.27

PPE strength: 0.135
PPE threshold: 0.08
Vignette: 120
Visual attack: 3.80
Visual release: 0.65

Pistol: 0.80
SMG: 1.20
Rifle: 1.45
Shotgun: 1.65
DMR: 2.40
Sniper: 3.00
Machine gun: 3.00
Heavy: 3.50

СОВМЕСТИМОСТЬ / АРХИТЕКТУРА
----------------------------
Мод не заменяет базовые XML напрямую.
Один HUD-static добавляется через DXML.
MCM не является обязательной зависимостью.

Внутренний MCM ID оставлен "r1sup", чтобы настройки пользователей
тестовых версий не сбрасывались после обновления.

ОБНОВЛЕНИЕ СО СТАРЫХ ТЕСТОВ
----------------------------
Старые экспериментальные файлы больше не используются и могут быть удалены:

gamedata/anims/r1nk1_suppression_bw.ppe

Старые DDS:
r1nk1_suppression_weak.dds
r1nk1_suppression_medium.dds
r1nk1_suppression_strong.dds
r1nk1_suppression_01.dds ... r1nk1_suppression_32.dds

НЕ удалять:
r1nk1_suppression_vignette.dds

ФИНАЛЬНАЯ СБОРКА СОДЕРЖИТ
-------------------------
- 1 основной Lua-скрипт
- 1 MCM-скрипт
- 1 DXML-скрипт
- 1 DDS-виньетку
- RU/ENG MCM localization

Лог успешной загрузки:
[R1nk1 Suppressed] v1.0 FINAL loaded
