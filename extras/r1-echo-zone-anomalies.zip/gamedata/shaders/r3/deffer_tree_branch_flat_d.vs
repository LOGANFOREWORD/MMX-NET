// R1nk1 modifications only: automatic dispatch / foliage integration.
// Copyright (c) 2026 R1nk1
// Licensed under the R1 Non-Monetized Modpack License v1.0
// License: https://github.com/noname-r1nk1/R1-License
// Original Anomaly/GSC and SSS code retains its original authorship and terms.
// Echo foliage: stock tree vertex path.
#include "deffer_tree_flat_d.vs"
