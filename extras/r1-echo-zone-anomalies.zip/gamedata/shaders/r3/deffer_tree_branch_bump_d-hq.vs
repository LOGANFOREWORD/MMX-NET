// R1nk1 modifications only: automatic dispatch / foliage integration.
// Copyright (c) 2026 R1nk1
// Licensed under the R1 Non-Monetized Modpack License v1.0
// License: https://github.com/noname-r1nk1/R1-License
// Original Anomaly/GSC and SSS code retains its original authorship and terms.
// R1 Echo: automatic shader-stack selection, no installer choice.
#define USE_TDETAIL
#define USE_PARALLAX
#include "common.h"
#ifdef SSFX_MV_LOADED
#define	USE_TDETAIL
#define USE_PARALLAX
#include "deffer_tree_bump.vs"

#else
// Echo foliage: stock tree vertex path.
#include "deffer_tree_bump_d-hq.vs"

#endif
