-- Copyright (c) 2026 R1nk1
-- Licensed under the R1 Non-Monetized Modpack License v1.0
-- License: https://github.com/noname-r1nk1/R1-License
-- Independent world attachment only; same forward/distortion path as vanilla windows.
function normal(shader,t_base,t_second,t_detail)
 shader:begin("r1ev_glass","r1ev_glass")
  :sorting(3,true):blend(true,blend.srcalpha,blend.invsrcalpha):zb(true,false):fog(false):dx10cullmode(2)
 shader:dx10texture("s_distort","pfx\\pfx_dist_glass")
 shader:dx10texture("s_env","sky\\sky_5_cube")
 shader:dx10sampler("smp_linear")
 shader:dx10sampler("smp_rtlinear")
end
function l_special(shader,t_base,t_second,t_detail)
 shader:begin("r1ev_glass","r1ev_glass_distort")
  :sorting(3,true):blend(true,blend.srcalpha,blend.invsrcalpha):zb(true,false):fog(false):distort(true):dx10cullmode(2)
 shader:dx10texture("s_distort","pfx\\pfx_dist_glass")
 shader:dx10sampler("smp_linear")
end
