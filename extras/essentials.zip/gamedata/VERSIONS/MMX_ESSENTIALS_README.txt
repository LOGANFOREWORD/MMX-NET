MMX-Net Essentials Survival (opzionale)
======================================

Pacchetto consigliato ma NON obbligatorio per Join / Invite.
Niente MGI. Niente shader / AI / gameplay inventati in questo zip.

Core coop (anti-CTD sessione) — arriva con AGGIORNA / overlay pack:
  - alife_release ownership / offline-before-free
  - inventory send-money + anchor guard
  - dual message_box EXE bridge
  - currency pack include
  - radio FM soft-match
  - death_manager proxy nil-rank + ChangeLevel join guard
  - (residuali Core, non qui): meet storage nil, rf/hf alife peer, sleepbag/tent

Questo zip (extras/essentials.zip):
  - marker MMX_ESSENTIALS.ltx (detect Addons / HEALTH INFO)
  - questa nota + safe defaults coop (testo)
  - futuri fix Anomaly QoL SOLO se supportati da soft.log / CTD noti

Safe defaults coop (consigli amici — non applicati automaticamente):
  - Installa MCM completo + Engine Base Coop dalle card dedicate (stesso tab).
  - Dopo AGGIORNA, fingerprint overlay allineato prima del Join.
  - Non mischiare overlay parziali / zip custom sopra Core senza need.
  - Essentials Survival ≠ MCM ≠ Base Coop ≠ Mod Organizer.

Install: launcher → Addons → Essenziali → Installa Essentials Survival
  (feed extras/essentials.zip, oppure zip locale accanto al launcher).
Disinstalla: stesso tab → Disinstalla.

Documentazione: MMX-net/docs/ESSENTIALS.md
